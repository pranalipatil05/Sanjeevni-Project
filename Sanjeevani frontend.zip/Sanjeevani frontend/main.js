function sendMessage() {
alert('Message sent successfully!');
}